package co.edurekatraining;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;

public class Assignment2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String currentDir = System.getProperty("user.dir"); //java coding to 
		//get project directory
		System.out.println(currentDir);
		System.setProperty("webdriver.chrome.driver", currentDir + "\\drivers\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://rediffmail.com");
		System.out.println(driver.getTitle());
		//Money xpath /html/body/div[2]/div/div[2]/a[2]
		
		//Task 1 - Money
		System.out.println("Using XPath" +driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/a[2]")).getText());
		// driver.quit();
		String x = driver.findElement(By.className("moneyicon")).getText();
		System.out.println("Using Partial Class name (due to compound class name error) " + x);
		//css selector
		x = driver.findElement(By.cssSelector("a.moneyicon.relative")).getText();
		System.out.println("Using Css selector  " + x);
		
		/*Task 2
		 * 2. Inspect all the textboxes with the below-mentioned locators.
			A) Inspect with name locator
			B) Inspect with id locator
		 */
		//Money searc
		
		driver.switchTo().frame("moneyiframe");
		WebElement MoneyText = driver.findElement(By.id("query"));  //By.xpath://*[@id='diagnosisivd']
		MoneyText.sendKeys("SMSI");
		System.out.println("Using Id - Mutal Fund search text  " + MoneyText.getAttribute("value"));
		//Using Name
		MoneyText = driver.findElement(By.name("query"));
		MoneyText.clear();
		MoneyText.sendKeys("VTI");
		System.out.println("Using Name - Mutual Fund search text  " + MoneyText.getAttribute("value"));
		driver.switchTo().defaultContent();
		//Shoppoing text
		WebElement ShopText = driver.findElement(By.id("srchword"));
		ShopText.sendKeys("Books");
		System.out.println("Using Id - Shoppning Fund search text  " + ShopText.getAttribute("value"));
		//Using Name
		ShopText = driver.findElement(By.name("srchword"));
		ShopText.clear();
		ShopText.sendKeys("Movies");
		System.out.println("Using Name - Mutual Fund search text  " + ShopText.getAttribute("value"));
		//Product search
		WebElement PdtText = driver.findElement(By.id("srchquery_tbox"));	
		PdtText.sendKeys("Books");
		System.out.println("Using Id - Product search text  " +PdtText.getAttribute("value"));
				//Using Name
		PdtText = driver.findElement(By.name("srchquery_tbox"));
		PdtText.clear();
		PdtText.sendKeys("Clothes");
		System.out.println("Using Name - Product search text  " + PdtText.getAttribute("value"));
				//Mail Text
		/*WebElement MailText = driver.findElement(By.xpath("//input[@id='sub_email_in']"));
		MailText.sendKeys("Mail Text");
		System.out.println("Using Id - Mail Text 1 " +MailText.getAttribute("value"));
				//Using Name
		MailText = driver.findElement(By.xpath("//input[@name='sub_email_in']"));
		MailText.clear();
		MailText.sendKeys("Mail Text1");
		System.out.println("Using Name - Mail Text 1 " + MailText.getAttribute("value"));
		
		//sub_email_in_top
				
	   */
		//Task 3
				/*. Inspect the below-mentioned elements.
				A) Rediffmail.com, enterprise email, videos, business email, shopping, sign in,  
				and create an account
				B) Inspect all the links present on Rediff.com
				4. Inspect the “sign in” link and click on it (Highlighted in red)
				
				*/;
				
		WebElement RDLogo = driver.findElement(By.xpath("//span[@class='hmsprite logo']"));
	    System.out.println("logo class name - " + RDLogo.getAttribute("class"));
	    WebElement RDMail = driver.findElement(By.linkText("Rediffmail"));
	    System.out.println("Link RDMail - " + RDMail.getAttribute("title"));
	    WebElement BMail = driver.findElement(By.linkText("Business Email"));
	    System.out.println("Link BMail - " + BMail.getAttribute("href")+ " " + BMail.getAttribute("title"));
	    WebElement Video = driver.findElement(By.linkText("Videos"));
	    System.out.println("Link Videos - " + Video.getAttribute("href") + " " + Video.getAttribute("title"));
	    WebElement Shopping = driver.findElement(By.linkText("Shopping"));
	    System.out.println("Link Online Shopping - " + Shopping.getAttribute("href") + " " + Shopping.getAttribute("title"));
	   
	    WebElement CreateAccount = driver.findElement(By.linkText("Create Account"));
	    System.out.println("Link Signin - " + CreateAccount.getAttribute("href")+ " " + CreateAccount.getAttribute("title"));
	
	    WebElement Signin = driver.findElement(By.linkText("Sign in"));
	    System.out.println("Link Signin - " + Signin.getAttribute("href")+ " " + Signin.getAttribute("title"));
	    Signin.click();
	    //	driver.quit();
		
}
}